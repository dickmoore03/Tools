Hex Workshop v4.2, the Professional Hex Editor
Copyright 1995-2004 BreakPoint Software, Inc.
32 bit version - hw32v423.exe

-[ Description ]--------------------------------------------------------

Hex Workshop is a set of hexadecimal development tools for Windows  9x,
NT, 2000, and XP.  It combines advanced binary editing with the ease and
flexibility of a word processor. With Hex Workshop you can edit, insert,
delete, cut, copy, and paste hex, print high quality customizable hex
dumps, and export to RTF or HTML for publishing.  Additionally, you can
goto, find, replace, compare, and calculate checksums within a file.

An Integrated Structure Viewer allows you to view and edit data in the
most intuitive and convenient way. This feature helps turn the art of
hex editing into a simple straightforward task. Structures are defined
in a text file that closely resemble the C/C++ style struct definitions.

Hex Workshop supports drag and drop and is integrated with the Windows
operating system so you can quickly and easily hex edit from your most
frequently used workspaces. The Data Inspector is perfect for
interpreting, viewing, and editing decimal and binary values.
Arithmetic, logical, ASCII case, and bitwise operations can be used to
help manipulation your data in place.   

-[ Changes ]------------------------------------------------------------

New Features and Enhancements in Hex Workshop v4.2:

- The Structure Viewer now supports 8, 16, 32 and 64 bit bitfields.
  A bitfield as defined by the C langauge allows users to modify and
  manipulate data without manually counting, shifting, or masking bits.

- Users can now specify the data type length when exporting data as C
  source or Java source.  8, 16, 32, and 64 bit data types and byte
  swapping are also supported.

- Hex Workshop can now be used to export data in the Base64 and
  UUEncoding formats.  Copy-As support is also available.

- Users can now modify the starting offset and view file offsets
  in terms of bytes (default), number of words (bytes/2), or dwords
  (bytes/4).  The offset display is controlled by right clicking on the
  address column of the hex display.

- Bookmarks are now easier to use and more useful.  The result of
  selecting or double-clicking a bookmark is different:
    - Selecting bookmark: Scrolls the bookmark into view without
      changing the cursor position.
    - Double-clicking bookmark's address: Moves the cursor position to
      the bookmark's address.
    - Double-clicking length: Selects the bookmark data within the
      editor.
    - Double-clicking bookmark's description: Allows you to edit the
      description in place.
    - Double-clicking bookmark's value: If a data type was supplied,
      allows you to edit the data in place.
      
- The Results Window has new "Output" tab to aid in development of
  structure definitions.  Debugging information and errors are displayed
  in the "Output" window whenever a user opens a new structure
  definition file. 

- The Structure Viewer's right-click popup menu now contains menu
  entries for "Copy" and "Edit".

- The Export As dialog now contains a button to modify export
  preferences.  This allows users to more easily change their export
  preferences.

- F2 may now be used to begin editing the selected structure viewer
  value.

- Ctrl+C now copies values to the clipboard from the Data Inspector and
  Structure Viewer.

Bugs Fixed in Hex Workshop v4.2:

- Hex Workshop's failure to read all sectors on large disks.

- Motorola S-Records were not imported correctly when records 
  overlapped or records were out of order.

- Typo in ANSI character map (online help).

- Failure of the delete key to remove the selected bookmark.

- Removed the left and right scroll buttons from the Data  Inspector's
  and Results Window's tab control.

- Defaults file extensions were not applied when changing format types
  in the Export As dialog.

- Redraw problems when repositioning floating structures containing
  array elements.

- "Junk entires" are no longer left after collapsing some structure
  definitions.

- Structure Viewer parsing problems for "typedef enum".

- Structure Viewer parsing/evaluation problems for signed and unsigned
  modifiers.

For a complete list of new features and product enhancements, see the
"history.txt" file located in the installation directory or visit us
online at http://www.hexworkshop.com/version_history.html.

-[ More Info ]----------------------------------------------------------

Check out our WWW Home Pages,

    http://www.bpsoft.com
    http://www.hexworkshop.com

for the latest Hex Workshop information (including new version
announcements and betas) and to join the Hex Workshop Mailing List.

-[ Upgrading ]----------------------------------------------------------

Upgrade Notes:

It is recommended that users uninstall Hex Workshop v4.1 and earlier
prior to installation.   Hex Workshop v4.21 can be safely installed on
top of Hex Workshop v4.20.  For other migrations paths, users need to
manually migrate their colormaps, bookmark files, and structure
definitions to the new installation directory.  Custom editor colors are
stored in the Windows registry and must be re-defined for the new
installation. 

Hex Workshop v1.x, v2.x, and v3.x customers may upgrade to Hex 
Workshop v4.2 at a reduce cost.  Please see the "UpgradeNow.html" file
in your installation directory or visit
http://www.hexworkshop.com/ordering for more information.

Hex Workshop v4.x customers are entitled to a free upgrade. Hex Workshop
v4.x keys will continue to unlock Hex Workshop v4.2.

-[ Unlocking ]----------------------------------------------------------

Unlocking Hex Workshop:

Hex Workshop can be unlocked from the Hex Workshop About Box 
(located under the Help|About Hex Workshop Menu) by clicking the
"Register" button.

-[ Distribution ]-------------------------------------------------------

You may copy and distribute the unmodified demonstration version of 
this software in electronic form.  You are prohibited from charging 
for or distributing this software with other products (commercial or
otherwise) without the expressed permission of BreakPoint Software, 
Inc.

-[ Contacting Us ]------------------------------------------------------

Please direct any inquiries to BreakPoint Software:

    Internet:           info@bpsoft.com

    Web:                http://www.bpsoft.com
                        http://www.hexworkshop.com

Hex Workshop can be ordered for $49.95.  See the "OrderNow.html" file
located in your installation directory, or visit
http://www.hexworkshop.com/ordering for more information.
